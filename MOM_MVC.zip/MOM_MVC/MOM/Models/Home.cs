﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MOM.Models
{
    public class Home
    {
        public string ProjectId { get; set; }
        public string ProjectName { get; set; }
        public string SelectedProject { get; set; }
        public IList<SelectListItem> Project { get; set; }
    }
}