﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MOM.Utilities;
using System.Net;
using System.Web.Script.Serialization;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Text;
using MOM.Models;
using System.Collections;
using System.Configuration;
using Newtonsoft.Json;
using System.Web.Configuration;

namespace MOM.Controllers
{
    public class MOMController : Controller
    {
        private static readonly log4net.ILog log =
    log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
       
        public static string serviceURL = string.Empty;



        [HttpGet]
        public ActionResult Home()
        {
                Home model = new Home();
                IList<Home> configData = new List<Home>();
                try
                {
                    serviceURL = string.Format(ConfigurationManager.AppSettings["RestService"] + ConfigurationManager.AppSettings["GetMOMProjects"]);
                    configData = serviceURL.GetServiceData<IList<Home>>();
                    model.Project = (from cd in configData
                                     select new SelectListItem
                                     {
                                         Text = cd.ProjectName,
                                         Value = cd.ProjectId
                                     }).ToList();
                    model.Project = model.Project.OrderBy(q => q.Value).ToList();
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message, ex);
                    //throw;
                }
                return View(model);          
            
        }

        [HttpPost]
        public ActionResult Home(Home model)
        {
            Session["Project"] = model.SelectedProject;
            return RedirectToAction("MOMStatus");
        }

        public MOMStatus GetUsers()
        {
            MOMStatus momModel = new MOMStatus();

            IList<MOMStatus> configData = new List<MOMStatus>();
            IList<SelectListItem> cntTasks = new List<SelectListItem>();

            try
            {
                serviceURL = string.Format(ConfigurationManager.AppSettings["RestService"] + ConfigurationManager.AppSettings["GetConfigurationData"], Convert.ToString(Session["Project"]));
                configData = serviceURL.GetServiceData<IList<MOMStatus>>();
                momModel.User = (from cd in configData
                                 select new SelectListItem
                                 {
                                     Text = cd.UserName,
                                     Value = cd.UserId
                                 }).ToList();
                momModel.User = momModel.User.OrderBy(q => q.Value).ToList();

                cntTasks.Add(new SelectListItem
                {
                    Text = "1",
                    Value = "1"
                });
                cntTasks.Add(new SelectListItem
                {
                    Text = "2",
                    Value = "2"
                });
                cntTasks.Add(new SelectListItem
                {
                    Text = "3",
                    Value = "3"
                });
                cntTasks.Add(new SelectListItem
                {
                    Text = "4",
                    Value = "4"
                });
                cntTasks.Add(new SelectListItem
                {
                    Text = "5",
                    Value = "5"
                });
                cntTasks.Add(new SelectListItem
                {
                    Text = "6",
                    Value = "6"
                });
                momModel.Count = cntTasks;
            }
            catch (Exception ex)
            {
                
                //throw;
                log.Error(ex.Message,ex);
            }
            return momModel;
        }

        public Reports GetStatusList()
        {
            Reports repModel = new Reports();
            SelectListItem listStatus = new SelectListItem();
            listStatus.Text = "All";
            listStatus.Value="0";
            IList<Reports> configData =new List<Reports>();

            try
            {
                serviceURL = string.Format(ConfigurationManager.AppSettings["RestService"] + ConfigurationManager.AppSettings["GetConfigDataReport"]);
                configData = serviceURL.GetServiceData<IList<Reports>>();
                repModel.Status = (from cd in configData
                                   select new SelectListItem
                                   {
                                       Text = cd.StatusName,
                                       Value = cd.StatusId
                                   }).ToList();
                repModel.Status.Add(listStatus);
                repModel.Status = repModel.Status.OrderBy(q => q.Value).ToList();
            }
            catch (Exception ex)
            {
                
                //throw;
                log.Error(ex.Message, ex);
            }
           
            return repModel;
        }
        
        [HttpGet]
        public ActionResult MOMStatus()
        {
            if (Session["Project"] != null)
            {
                MOMStatus momModel = new MOMStatus();
                momModel = GetUsers();
                Session["MOM"] = momModel;
                return View(momModel);
            }
            else
            {
                return RedirectToAction("Home");
            }
        }

        [HttpPost]
        public ActionResult MOMStatus(MOMStatus model, string SelectedUser = "", string decision = "")
        {
            if (Session["Project"] != null)
            {
                MOMStatus momModel = new MOMStatus();
                IList<ActivityModel> listActModel = new List<ActivityModel>();
                try
                {
                    
                    momModel = (MOMStatus)Session["MOM"];
                    momModel.SelectedUser = model.SelectedUser;
                    momModel.SelectedCount = model.SelectedCount;
                    momModel.Date = model.Date;
                    momModel.Result = "";
                    
                    if (decision == "Insert" || decision == "Update")
                    {
                        if (model.Activities != null)
                        {
                            int i = 0;
                            foreach (var activity in model.Activities)
                            {
                                ActivityModel momDetails = new ActivityModel();

                                momDetails.UserName = model.SelectedUser;
                                momDetails.Date = model.Date;
                                momDetails.ID = model.Activities[i].ID;
                                momDetails.Task = model.Activities[i].Task;
                                momDetails.Hours = model.Activities[i].Hours;
                                momDetails.Percentage = model.Activities[i].Percentage;
                                momDetails.StatusId = (model.Activities[i].Percentage == "100") ? 1 : 2;
                                if (model.Activities[i].IsChecked)
                                {
                                    momDetails.StatusId = (model.Activities[i].Percentage == "100") ? 1 : 4;
                                }

                                listActModel.Add(momDetails);
                                i++;
                            }
                            serviceURL = string.Format(ConfigurationManager.AppSettings["RestService"] + ConfigurationManager.AppSettings["InsertUpdateData"], decision);
                            string data = serviceURL.PostServiceData<IList<ActivityModel>>(listActModel);
                            bool result = Convert.ToBoolean(data);
                            momModel.SelectedUser = null;
                            momModel.SelectedCount = null;
                            momModel.Date = null;
                            momModel.Activities = null;
                            momModel.LastDate = null;
                            momModel.PendingStatus = null;
                            if (result)
                                momModel.Result = "Successfully Submitted";
                            else
                                momModel.Result = "Failed";
                        }
                    }
                    else
                    {
                        momModel.Result = "Failed";
                    }
                    
                }
                catch (Exception ex)
                {
                    
                    //throw;
                    log.Error(ex.Message,ex);
                }
                return View("MOMStatus", momModel);
            }
            else
            {
                return RedirectToAction("Home");
            }
        }

        public ActionResult ShowTasks(MOMStatus model, string SelectedUser, string SelectedCount, string selection = "", string decision = "")
        {
            MOMStatus momModel = new MOMStatus();
            IList<ActivityModel> list = new List<ActivityModel>();
            try
            {
                momModel = (MOMStatus)Session["MOM"];
                momModel.SelectedUser = model.SelectedUser;
                momModel.SelectedCount = model.SelectedCount;
                momModel.Date = model.Date;
                momModel.Result = "";

                if (selection == "User")
                {
                    serviceURL = string.Format(ConfigurationManager.AppSettings["RestService"] + ConfigurationManager.AppSettings["GetLastDate"], SelectedUser);
                    string date = serviceURL.GetServiceData<string>();

                    momModel.LastDate = (date == "") ? "Last Updated Date :  ------" : "Last Updated Date :  " + date;
                    momModel.SelectedUser = SelectedUser;
                    serviceURL = string.Format(ConfigurationManager.AppSettings["RestService"] + ConfigurationManager.AppSettings["GetMOMPendingData"], SelectedUser, 2);
                    momModel.Activities = serviceURL.GetServiceData<IList<ActivityModel>>();
                    momModel.SelectedCount = (momModel.Activities.Count == 0) ? null : momModel.Activities.Count.ToString();
                    momModel.PendingStatus = (momModel.Activities.Count == 0) ? null : "Please take action on below items and proceed : You can either increase hours,percentage or Check remove to move it to Hold status";
                }
                else if (selection == "Count")
                {
                    momModel.SelectedCount = SelectedCount;
                    momModel.Activities = null;
                    momModel.PendingStatus = null;
                }
            }
            catch (Exception ex)
            {
                
                //throw;
                log.Error(ex.Message,ex);
            }

            return PartialView("ShowTasks", momModel);
        }

        [HttpGet]
        public ActionResult Reports()
        {
            if (Session["Project"] != null)
            {
                Reports repmodel = new Reports();
                repmodel = GetStatusList();
                Session["Reports"] = repmodel;
                return View(repmodel);
            }
            else
            {
                return RedirectToAction("Home");
            }
        
        }

        [HttpPost]
        public ActionResult Reports(Reports model, string decision = "")
        {
            if (Session["Project"] != null)
            {
                Reports repmodel = new Reports();
                try
                {
                    repmodel = (Reports)Session["Reports"];
                    if (model.StartDate != null && model.EndDate != null && model.SelectedStatus != null)
                    {
                        DataTable dt = new DataTable();
                        IList<ActivityModel> listActModel = new List<ActivityModel>();
                        if (model.SelectedStatus == "0")
                        {
                            model.SelectedStatus = "1,2,3,4";
                        }
                        serviceURL = string.Format(ConfigurationManager.AppSettings["RestService"] + ConfigurationManager.AppSettings["GetMOMData"], model.StartDate, model.EndDate, model.SelectedStatus, Convert.ToString(Session["Project"]));
                        listActModel = serviceURL.GetServiceData<IList<ActivityModel>>();
                        dt = listActModel.ListToDataTable<ActivityModel>();
                        dt.Columns["UserName"].ColumnName = "AssociateName";
                        dt.Columns.Remove("ID");
                        dt.Columns.Remove("StatusId");
                        dt.Columns.Remove("IsChecked");
                        if (decision == "export")
                        {
                            string fileName = "Report_" + Convert.ToDateTime(model.StartDate).ToShortDateString() + " to " + Convert.ToDateTime(model.EndDate).ToShortDateString();
                            Common.ExportToExcel(dt, Response, fileName, "Report");
                        }
                    }
                }
                catch (Exception ex)
                {
                    
                    //throw;
                    log.Error(ex.Message,ex);
                }

                return View(repmodel);
            }
            else
            {
                return RedirectToAction("Home");
            }
        }

        public ActionResult ShowReport(string startDate, string endDate, string selectedStatus, string decision = "", string search = "")
        {
            Reports repmodel = new Reports();
            try
            {
                if (startDate != null && endDate != null && selectedStatus != null)
                {
                    IList<ActivityModel> listActModel = new List<ActivityModel>();
                    if (selectedStatus == "0")
                    {
                        selectedStatus = "1,2,3,4";
                    }
                    serviceURL = string.Format(ConfigurationManager.AppSettings["RestService"] + ConfigurationManager.AppSettings["GetMOMData"], startDate, endDate, selectedStatus, Convert.ToString(Session["Project"]));
                    listActModel = serviceURL.GetServiceData<IList<ActivityModel>>();
                    if (decision == "showgrid")
                    {
                        repmodel.ReportsModel = listActModel;
                        Session["GridData"] = repmodel.ReportsModel;
                        Session["currentData"] = null;
                        return PartialView("ShowReport", Session["GridData"]);
                    }
                }
                else if (!string.IsNullOrEmpty(search))
                {
                    if (Session["GridData"] != null)
                    {
                        repmodel.ReportsModel = (IList<ActivityModel>)Session["GridData"];
                        repmodel.ReportsModel = repmodel.ReportsModel.Where(q => q.UserName.ToLower().Contains(search.ToLower())).ToList();
                        Session["currentData"] = repmodel.ReportsModel;
                        return PartialView("ShowReport", Session["currentData"]);
                    }
                }
                else if (Session["currentData"] != null)
                {
                    return PartialView("ShowReport", Session["currentData"]);
                }
                else
                {
                    return PartialView("ShowReport", Session["GridData"]);
                }
            }
            catch (Exception ex)
            {
                
                //throw;
                log.Error(ex.Message,ex);
            }
            return PartialView("ShowReport", Session["GridData"]);
        }

        public ActionResult ShowCompleteReport()
        {
            if (Session["currentData"] != null)
            {
                Session["currentData"] = null;
            }            
            return PartialView("ShowReport", Session["GridData"]);
            
        }

        public ActionResult DownloadCurentData()
        {
            IList<ActivityModel> listActModel = new List<ActivityModel>();
            DataTable dt = new DataTable();
            if (Session["currentData"] != null)
            {                
                listActModel = (IList<ActivityModel>)Session["currentData"];
                dt = listActModel.ListToDataTable<ActivityModel>();
            }
            else 
            {
                listActModel = (IList<ActivityModel>)Session["GridData"];
                dt = listActModel.ListToDataTable<ActivityModel>();
            }
            dt.Columns["UserName"].ColumnName = "AssociateName";
            dt.Columns.Remove("ID");
            dt.Columns.Remove("StatusId");
            dt.Columns.Remove("IsChecked");
            string fileName = "Report";
            Common.ExportToExcel(dt, Response, fileName, "Report");
            return Json("");
        }

        public ActionResult Help()
        {
            if (Session["Project"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Home");
            }
        }    

    }
}
