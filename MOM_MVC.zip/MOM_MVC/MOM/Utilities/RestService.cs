﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using Newtonsoft.Json;
using System.Text;

namespace MOM.Utilities
{
    public static class RestService
    {
        public static string GetServiceData(this string serviceURL)
        {
            WebClient webClient = new WebClient();
            var data = webClient.DownloadString(serviceURL);
            return data;
        }

        public static T Deserialize<T>(this string json)
        {
            T obj = JsonConvert.DeserializeObject<T>(json);
            return obj;
        }


        public static T GetServiceData<T>(this string serviceURL)
        {
            WebClient webClient = new WebClient();
            var json = webClient.DownloadString(serviceURL);
            T obj = JsonConvert.DeserializeObject<T>(json);
            return obj;
        }

        public static string PostServiceData<T>(this string serviceURL, T model)
        {
            WebClient webClient = new WebClient();
            webClient.Headers["Content-type"] = "application/json";
            webClient.Encoding = Encoding.UTF8;
            string json = JsonConvert.SerializeObject(model);
            string data = webClient.UploadString(serviceURL, "POST", json);
            return data;
        }

        public static string UpdateServiceData<T>(this string serviceURL, T model)
        {
            WebClient webClient = new WebClient();
            webClient.Headers["Content-type"] = "application/json";
            webClient.Encoding = Encoding.UTF8;
            string json = JsonConvert.SerializeObject(model);
            string data = webClient.UploadString(serviceURL, "PUT", json);
            return data;
        }


        public static string DeleteServiceData<T>(this string serviceURL, T model)
        {
            WebClient webClient = new WebClient();
            webClient.Headers["Content-type"] = "application/json";
            webClient.Encoding = Encoding.UTF8;
            string json = JsonConvert.SerializeObject(model);
            string data = webClient.UploadString(serviceURL, "DELETE", json);
            return data;
        }

        public static string DeleteServiceData(this string serviceURL, string id)
        {
            WebClient webClient = new WebClient();
            webClient.Headers["Content-type"] = "application/json";
            webClient.Encoding = Encoding.UTF8;
            string json = JsonConvert.SerializeObject(id);
            string data = webClient.UploadString(serviceURL, "DELETE", json);
            return data;
        }
    }
}