﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Linq;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Serialization;
using System.Data;
using System.Reflection;
//using Microsoft.Office.Tools.Excel;
using ClosedXML.Excel;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using System.ComponentModel;
using Newtonsoft.Json;

namespace MOM.Utilities
{
    public static class Common
    {
        

        //public static string ListToXml(this List<ActivityModel> employees)
        //{
        //    var xEle = new XElement("MOM",
        //            from emp in employees
        //            select new XElement("Data",
        //                           new XElement("Task", emp.Task),
        //                           new XElement("Hours", emp.Hours),
        //                           new XElement("Percent", emp.Percentage)

        //                       ));
        //    StringWriter sw = new StringWriter();
        //    XmlTextWriter tx = new XmlTextWriter(sw);
        //    xEle.WriteTo(tx);

        //    string str = sw.ToString();
        //    return xEle.ToString();
        //}

        public static string ListToXML<TSource>(this List<TSource> data)
        {
            string xml = string.Empty;
            XmlDocument xmlDoc = new XmlDocument();
            XPathNavigator nav = xmlDoc.CreateNavigator();
            using (XmlWriter writer = nav.AppendChild())
            {
                XmlSerializer ser = new XmlSerializer(typeof(List<TSource>));
                ser.Serialize(writer, data);
            }
            string s = "ArrayOf" + typeof(TSource).Name;
            string strXML = nav.InnerXml;
            strXML = strXML.Replace("ArrayOf" + typeof(TSource).Name, "root");
            strXML = strXML.Replace(typeof(TSource).Name, "row");
            xml = strXML.ToString();
            return xml;
        }

        public static DataTable ListToDataTable<T>(this IList<T> data)
        {
            PropertyDescriptorCollection props =
                TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            for (int i = 0; i < props.Count; i++)
            {
                PropertyDescriptor prop = props[i];
                if (prop.PropertyType.IsGenericType && prop.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>))
                    table.Columns.Add(prop.Name, prop.PropertyType.GetGenericArguments()[0]);
                else
                    table.Columns.Add(prop.Name, prop.PropertyType);
            }
            object[] values = new object[props.Count];
            foreach (T item in data)
            {
                for (int i = 0; i < values.Length; i++)
                {
                    values[i] = props[i].GetValue(item);
                }
                table.Rows.Add(values);
            }
            return table;
        }

        public static List<TSource> DataTableToList<TSource>(this DataTable dataTable) where TSource : new()
        {
            var dataList = new List<TSource>();

            const BindingFlags flags = BindingFlags.Public | BindingFlags.Instance | BindingFlags.NonPublic;
            var objFieldNames = (from PropertyInfo aProp in typeof(TSource).GetProperties(flags)
                                 select new
                                 {
                                     Name = aProp.Name,
                                     Type = Nullable.GetUnderlyingType(aProp.PropertyType) ??
                             aProp.PropertyType
                                 }).ToList();
            var dataTblFieldNames = (from DataColumn aHeader in dataTable.Columns
                                     select new
                                     {
                                         Name = aHeader.ColumnName,
                                         Type = aHeader.DataType
                                     }).ToList();
            var commonFields = objFieldNames.Intersect(dataTblFieldNames).ToList();

            foreach (DataRow dataRow in dataTable.AsEnumerable().ToList())
            {
                var aTSource = new TSource();
                foreach (var aField in commonFields)
                {
                    PropertyInfo propertyInfos = aTSource.GetType().GetProperty(aField.Name);
                    var value = (dataRow[aField.Name] == DBNull.Value) ?
                    null : dataRow[aField.Name]; //if database field is nullable
                    propertyInfos.SetValue(aTSource, value, null);
                }
                dataList.Add(aTSource);
            }
            return dataList;
        }



        /// <summary>
        /// FUNCTION FOR EXPORT TO EXCEL
        /// </summary>
        /// <param name="dataTable"></param>
        /// <param name="worksheetName"></param>
        /// <param name="saveAsLocation"></param>
        /// <returns></returns>
        public static void WriteDataTableToExcel(System.Data.DataTable dataTable, string worksheetName, string saveAsLocation, string startDate, string endDate)
        {
            Microsoft.Office.Interop.Excel.Application excel;
            Microsoft.Office.Interop.Excel.Workbook excelworkBook;
            Microsoft.Office.Interop.Excel.Worksheet excelSheet;
            Microsoft.Office.Interop.Excel.Range excelCellrange;

            try
            {
                // Start Excel and get Application object.
                excel = new Microsoft.Office.Interop.Excel.Application();

                // for making Excel visible
                excel.Visible = false;
                excel.DisplayAlerts = false;

                // Creation a new Workbook
                excelworkBook = excel.Workbooks.Add(Type.Missing);

                // Work sheet
                excelSheet = (Microsoft.Office.Interop.Excel.Worksheet)excelworkBook.ActiveSheet;
                excelSheet.Name = worksheetName;


                excelSheet.Cells[1, 1] = "Topic for the Meeting: ";
                excelSheet.Cells[1, 2] = "Steam RMD Performance Metrics Daily SCRUM call";
                excelSheet.Cells[2, 1] = "Date : ";
                excelSheet.Cells[2, 2] = Convert.ToDateTime(startDate).ToShortDateString() + " To " + Convert.ToDateTime(endDate).ToShortDateString();

                excelSheet.Cells[3, 1] = "Circle: ";
                excelSheet.Cells[3, 2] = "IBU GE";
                excelSheet.Cells[4, 1] = "Schedule Time of start: ";
                excelSheet.Cells[4, 2] = "18:00hrs.";

                excelSheet.Cells[5, 1] = "Actual Time of start: ";
                excelSheet.Cells[5, 2] = "18:00 hrs.";
                excelSheet.Cells[6, 1] = "Venue: ";
                excelSheet.Cells[6, 2] = "Conference Call";

                excelSheet.Cells[7, 1] = "Planned Duration of the Meeting: ";
                excelSheet.Cells[7, 2] = "30  Min";
                excelSheet.Cells[8, 1] = "Actual Duration of the Meeting : ";
                excelSheet.Cells[8, 2] = "30  Min";

                // loop through each row and add values to our sheet
                int rowcount = 10;

                foreach (DataRow datarow in dataTable.Rows)
                {
                    rowcount += 1;
                    for (int i = 1; i <= dataTable.Columns.Count; i++)
                    {
                        // on the first iteration we add the column headers
                        if (rowcount == 11)
                        {
                            excelSheet.Cells[10, i] = dataTable.Columns[i - 1].ColumnName;
                            excelSheet.Cells.Font.Color = System.Drawing.Color.Black;
                            excelSheet.Cells[10, i].Interior.Color = System.Drawing.ColorTranslator.FromHtml("#FF0000");
                        }

                        excelSheet.Cells[rowcount, i] = datarow[i - 1].ToString();

                        //for alternate rows
                        //if (rowcount > 11)
                        //{
                        //    if (i == dataTable.Columns.Count)
                        //    {
                        //        if (rowcount % 2 == 0)
                        //        {
                        //            excelCellrange = excelSheet.Range[excelSheet.Cells[rowcount, 1], excelSheet.Cells[rowcount, dataTable.Columns.Count]];
                        //            FormattingExcelCells(excelCellrange, "#CCCCFF", System.Drawing.Color.Black, false);
                        //        }

                        //    }
                        //}

                    }

                }

                // now we resize the columns
                excelCellrange = excelSheet.Range[excelSheet.Cells[1, 1], excelSheet.Cells[rowcount, dataTable.Columns.Count]];
                excelCellrange.Font.Name = "Arial";
                excelCellrange.Font.Size = 12;
                excelCellrange.EntireColumn.AutoFit();
                excelCellrange.Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                Microsoft.Office.Interop.Excel.Borders border = excelCellrange.Borders;
                border.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
                border.Weight = 2d;


                excelCellrange = excelSheet.Range[excelSheet.Cells[1, 1], excelSheet.Cells[8, 1]];
                FormattingExcelCells(excelCellrange, "#FF0000", System.Drawing.Color.White, true);

                excelCellrange = excelSheet.Range[excelSheet.Cells[1, 2], excelSheet.Cells[8, 2]];
                FormattingExcelCells(excelCellrange, "#FF0000", System.Drawing.Color.White, false);


                //now save the workbook and exit Excel


                excelworkBook.SaveAs(saveAsLocation); ;
                excelworkBook.Close();
                excel.Quit();
                //return true;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                excelSheet = null;
                excelCellrange = null;
                excelworkBook = null;
            }

        }

        /// <summary>
        /// FUNCTION FOR FORMATTING EXCEL CELLS
        /// </summary>
        /// <param name="range"></param>
        /// <param name="HTMLcolorCode"></param>
        /// <param name="fontColor"></param>
        /// <param name="IsFontbool"></param>
        public static void FormattingExcelCells(Microsoft.Office.Interop.Excel.Range range, string HTMLcolorCode, System.Drawing.Color fontColor, bool IsFontbool)
        {
            range.Interior.Color = System.Drawing.ColorTranslator.FromHtml(HTMLcolorCode);
            range.Font.Color = System.Drawing.ColorTranslator.ToOle(fontColor);
            if (IsFontbool == true)
            {
                range.Font.Bold = IsFontbool;
            }
        }

        public static void ExportToExcel(DataTable dt, HttpResponseBase Response, string reportName, string sheetName)
        {

            int col = dt.Columns.Count;
            int row = dt.Rows.Count;
            try
            {
                using (XLWorkbook wb = new XLWorkbook())
                {
                    var ws = wb.Worksheets.Add(dt, sheetName);

                    ws.Style.Font.FontColor = XLColor.Black;
                    ws.Style.Font.FontName = "Arial";
                    ws.Columns().Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Left;
                    ws.Tables.FirstOrDefault().ShowAutoFilter = false;
                    //ws.Columns().AdjustToContents();
                    ws.Columns().Style.Alignment.WrapText = true;

                    var rangeData = ws.Range(2, 1, (1 + row), col);
                    rangeData.Style.Fill.BackgroundColor = XLColor.AliceBlue;
                    rangeData.Style.Font.FontSize = 10;
                    rangeData.Style.Font.Bold = false;                    

                    var rangeHead = ws.Range(1, 1, 1, col);
                    ws.Row(1).Height = 20;
                    rangeHead.Style.Fill.BackgroundColor = XLColor.DarkMidnightBlue;
                    rangeHead.Style.Font.FontColor = XLColor.Isabelline;
                    rangeHead.Style.Font.FontSize = 12;
                    rangeHead.Style.Font.Bold = true;

                    //ws.Column(1).AdjustToContents();
                    ws.Row(1).Style.Alignment.WrapText = false;

                    Response.Clear();
                    Response.Buffer = true;
                    Response.Charset = "";
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.AddHeader("content-disposition", "attachment;filename=" + reportName + ".xlsx");
                    using (MemoryStream MyMemoryStream = new MemoryStream())
                    {
                        wb.SaveAs(MyMemoryStream);
                        MyMemoryStream.WriteTo(Response.OutputStream);
                        Response.Flush();
                        Response.End();
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

    }
}