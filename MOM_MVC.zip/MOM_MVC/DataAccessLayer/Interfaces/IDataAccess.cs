﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccessLayer.Models;
using System.Data;

namespace DataAccessLayer.Interfaces
{
    public interface IDataAccess
    {
        IList<PopUp> GetMOMProjects();
        IList<Home> GetConfigurationData(string project);
        IList<Reports> GetConfigDataReport();
        bool InsertUpdateData(string data,string operation);
        DataTable GetMOMData(string startDate, string endDate, string selectedStatus, string project);

        string GetLastDate(int user);
        List<ActivityModel> GetMOMPendingData(string user, int statusId);
    }
}
