﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer.Interfaces;

namespace DataAccessLayer.Implementations
{
    public class DataAccess : IDataAccess
    {
        public DataTable GetDailyData(string Date)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            string status = ConfigurationManager.AppSettings["Status"];
            int project = Convert.ToInt16(ConfigurationManager.AppSettings["ProjectId"]);
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["STRMDConnectionString"].ConnectionString))
            {
                conn.Open();
                SqlCommand command = new SqlCommand("GetMOMDailyData", conn);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Date", Convert.ToDateTime(Date).ToShortDateString());
                command.Parameters.AddWithValue("@StatusId", status);
                command.Parameters.AddWithValue("@ProjectId", Convert.ToInt32(project));
                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(ds);
                dt = ds.Tables[0];
                dt.Columns["UserName"].ColumnName = "AssociateName";

                conn.Close();
            }

            return dt;
        }
    }
}
