﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace DataAccessLayer.Interfaces
{
    public interface IDataAccess
    {
        DataTable GetDailyData(string Date);
    }
}
