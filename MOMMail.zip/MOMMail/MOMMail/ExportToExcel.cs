﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using ClosedXML.Excel;
using System.Configuration;

namespace MOMMail
{
    public static class ExportToExcel
    {
        public static void Export(DataTable dt ,string filePath)
        {
            try
            {
                int col = dt.Columns.Count;
                int row = dt.Rows.Count;
                string currentDate = DateTime.Now.ToShortDateString();
                if (ConfigurationManager.AppSettings["OptionalDate"] != "")
                {
                    currentDate = Convert.ToDateTime(ConfigurationManager.AppSettings["OptionalDate"]).ToShortDateString();
                }

                var workbook = new XLWorkbook();
                var ws = workbook.Worksheets.Add("MOM Details");

                //Report Information
                ws.Cell(1, 1).Value = "Company Name";
                ws.Cell(2, 1).Value = "MINUTES OF THE MEETING";
                ws.Cell(3, 1).Value = "Topic for the Meeting: ";
                ws.Cell(3, 2).Value = "Daily SCRUM call";
                ws.Cell(4, 1).Value = "Date : ";
                ws.Cell(4, 2).Value = currentDate;
                ws.Cell(5, 1).Value = "Circle: ";
                ws.Cell(5, 2).Value = "IBU MM";
                ws.Cell(6, 1).Value = "Schedule Time of start: ";
                ws.Cell(6, 2).Value = ConfigurationManager.AppSettings["ScheduledTime"];
                ws.Cell(7, 1).Value = "Actual Time of start: ";
                ws.Cell(7, 2).Value = ConfigurationManager.AppSettings["ScheduledTime"];
                ws.Cell(8, 1).Value = "Venue: ";
                ws.Cell(8, 2).Value = "Conference Call";
                ws.Cell(9, 1).Value = "Planned Duration of the Meeting: ";
                ws.Cell(9, 2).Value = ConfigurationManager.AppSettings["Duration"];
                ws.Cell(10, 1).Value = "Actual Duration of the Meeting : ";
                ws.Cell(10, 2).Value = ConfigurationManager.AppSettings["Duration"];
                //DataTable
                ws.Cell(12, 1).InsertTable(dt);
                //Formatting
                ws.Style.Font.FontColor = XLColor.Black;
                ws.Style.Font.FontName = "Arial";
                ws.Columns().Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Left;
                ws.Tables.FirstOrDefault().ShowAutoFilter = false;

                var rangeTitle = ws.Range(1, 1, 10, 2);
                FormatExcel(rangeTitle, XLColor.DarkMidnightBlue, XLColor.Isabelline, 12, true);
                //ws.Columns("B:G").Width = 20;
                //var rngTitle = ws.Range("B2:G2");
                //var rangeTitle = ws.Range(1, 1, 10, 2);
                //rangeTitle.Style.Fill.BackgroundColor = XLColor.DarkMidnightBlue;
                //rangeTitle.Style.Font.FontColor = XLColor.Isabelline;
                //rangeTitle.Style.Font.FontSize = 12;
                //rangeTitle.Style.Font.Bold = true;

                var rangeTitleVal = ws.Range(3, 2, 10, 2);
                rangeTitleVal.Style.Font.Bold = false;

                var rangeHead = ws.Range(12, 1, 12, col);
                FormatExcel(rangeHead, XLColor.DarkMidnightBlue, XLColor.Isabelline, 12, true);
                ws.Row(12).Height = 20;

                var rangeData = ws.Range(13, 1, (12 + row), col);
                FormatExcel(rangeData, XLColor.AliceBlue, XLColor.Black, 10, false);

                //ws.Range(1, 1, 1, 2).Merge();
                //ws.Range(2, 1, 2, 2).Merge();
                //ws.Range("A1:A2").Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;

                ws.Range("A1:A2").Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;
               
                ws.Columns().AdjustToContents();

                workbook.SaveAs(filePath);
            }
            catch (Exception ex)
            {
                //MOMMail.Program.log.WriteLine(ex.Message);
                //MOMMail.Program.log.WriteLine(ex);
            }
        
        }


        public static void FormatExcel(IXLRange range,XLColor backColor,XLColor fontColor,int fontSize,bool isFontbool)
        {
            range.Style.Fill.BackgroundColor = backColor;
            range.Style.Font.FontColor = fontColor;
            range.Style.Font.FontSize = fontSize;
            range.Style.Font.Bold = isFontbool;
        }
    }
}
