﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Configuration;
using ClosedXML.Excel;
using System.Net.Mail;
using System.IO;
using DataAccessLayer.Interfaces;
using DataAccessLayer.Implementations;

namespace MOMMail
{
    public class Program
    {
        //log
        //public static StreamWriter log;
        private static readonly log4net.ILog log =
    log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        static void Main(string[] args)
        {
            IDataAccess da = new DataAccess();
            try
            {
                //if (!File.Exists(ConfigurationManager.AppSettings["LogPath"]))
                //{
                //    log = new StreamWriter(ConfigurationManager.AppSettings["LogPath"]);
                //}
                //else
                //{
                //    log = File.AppendText(ConfigurationManager.AppSettings["LogPath"]);
                //}
                //log.WriteLine(DateTime.Now + " Status Mail Service Tool Running...");

                log.Info("Status Mail Service Tool Running...");
                string date = DateTime.Now.ToLongDateString();
                if (ConfigurationManager.AppSettings["OptionalDate"] != "")
                {
                    date = Convert.ToDateTime(ConfigurationManager.AppSettings["OptionalDate"]).ToLongDateString();
                }
                string filePath = ConfigurationManager.AppSettings["Path"] + "\\Mom-Objects_" + date + ".xlsx";
                
                //Get Data From Database
                DataTable dt = new DataTable();
                dt = da.GetDailyData(date);
                if (dt.Rows.Count > 0)
                {

                    //Export the Data to Excel
                    ExportToExcel.Export(dt, filePath);

                    //Send Mail
                    SendMail(filePath);
                }
                else
                {
                    //log.WriteLine("No records found in the date :"+date);
                    log.Info("No records found in the date :" + date);
                }
                //log.WriteLine();
                //log.Close();
            }
            catch (Exception ex)
            {
                //log.WriteLine(ex.Message);
                //log.WriteLine(ex);
                log.Error(ex.Message,ex);

            }

        }


        //send mail
        private static void SendMail(string filePath)
        {
            try
            {
                string currentDate = DateTime.Now.Date.ToShortDateString();
                if (ConfigurationManager.AppSettings["OptionalDate"] != "")
                {
                    currentDate = Convert.ToDateTime(ConfigurationManager.AppSettings["OptionalDate"]).ToShortDateString();
                }
                Attachment attchment = new Attachment(filePath);
                var mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["fromAddress"], ConfigurationManager.AppSettings["fromDisplayName"]);
                mailMessage.Subject = ConfigurationManager.AppSettings["subject"] + currentDate;
                mailMessage.Body = "Hi All," + "<br/>" + "<br/>" + "Please find Mom - Updates as on " + currentDate + "<br/>" + "<br/>" +
                   "Regards" + "<br/>" + "Surya" + "<br/>" + "STRM&amp;D Performance Metrics" + "<br/>" + "Desk: +91-40-30633765" + "<br/>" + "surya.pavan@ge.com";

                if (ConfigurationManager.AppSettings["toAddress"] != "")
                {
                    string[] tomailLoop = ConfigurationManager.AppSettings["toAddress"].Split(',');
                    for (int i = 0; i < tomailLoop.Count(); i++)
                    {
                        mailMessage.To.Add(tomailLoop[i]);
                    }
                }
                if (ConfigurationManager.AppSettings["ccAddress"] != "")
                {
                    string[] ccmailLoop = ConfigurationManager.AppSettings["ccAddress"].Split(',');
                    for (int i = 0; i < ccmailLoop.Count(); i++)
                    {
                        mailMessage.CC.Add(ccmailLoop[i]);
                    }
                }
                mailMessage.IsBodyHtml = true;
                mailMessage.Attachments.Add(attchment);
                var smtp = new SmtpClient(ConfigurationManager.AppSettings["SMTPHost"]);
                smtp.Send(mailMessage);
                attchment.Dispose();
                //log.WriteLine(DateTime.Now + " Successfully Completed");
                log.Info("Successfully Completed");
            }
            catch (Exception ex)
            {
                //log.WriteLine(ex.Message);
                //log.WriteLine(ex);
                log.Error(ex.Message,ex);
            }
        }
    }
}
