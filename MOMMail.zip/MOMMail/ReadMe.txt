Schedule this application in windows task manager to run at
a specified time in the day.

This mail application fetches the data from database
and sends mail if data is available on a particular day.


configuration file settings:

1. Modify the connection string in app.config file and 
add your database credentials to connect.

2. Add the email id's in app settings to 
whom we should send the mail.

3. Add the project id for which we need to send the reports. 

4. Modify the OptionalDate value to empty to run for the current day.
(it runs for the specific day provided)